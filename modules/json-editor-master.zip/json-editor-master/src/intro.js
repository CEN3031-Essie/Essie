/*! JSON Editor v0.7.24 - JSON Schema -> HTML Editor
 * By Jeremy Dorn - https://github.com/jdorn/json-editor/
 * Released under the MIT license
 *
 * Date: 2016-02-11
 */

/**
 * See README.md for requirements and usage info
 */

(function() {
